package com.example.shashank.retorabit

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.JsonObject
import kotlinx.coroutines.*
import org.json.JSONObject
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
      retrofit()
    }
    private fun retrofit() {
        val baseUrl="https://api.publicapis.org/"
        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(Api::class.java)
        val view = findViewById<TextView>(R.id.TextView)
        GlobalScope.launch {
            val Results = retrofit.getUserDetails()
            withContext(Dispatchers.Main){
                Log.d("resp","${Result}")
                view.text = Results.toString()
            }
        }
    }

    interface Api {
        @GET("/entries")
        suspend fun getUserDetails():JsonObject
    }
}



